import { canonicalJson } from "./json.js";
import type { Evaluator, JsonValue } from "./types.js";

export function exactMatch<Input extends JsonValue = JsonValue, Output extends JsonValue = JsonValue>(): Evaluator<Input, Output> {
  return {
    id: "exact-match",
    version: "1",
    kind: "gate",
    threshold: 1,
    evaluate({ expected, output }) {
      if (expected === undefined) return { score: null, reason: "No reference output was provided" };
      const matches = canonicalJson(expected) === canonicalJson(output);
      return { score: matches ? 1 : 0, reason: matches ? "Output matches the reference" : "Output differs from the reference" };
    },
  };
}
