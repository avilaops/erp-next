import { canonicalJson } from "./json.js";
import type { Evaluator, JsonValue } from "./types.js";

export function exactMatch<Input extends JsonValue = JsonValue, Output extends JsonValue = JsonValue>(): Evaluator<Input, Output> {
  return {
    id: "exact-match",
    version: "1",
    kind: "gate",
    threshold: 1,
    evaluate({ expected, output }) {
      if (expected === undefined) return { score: null, reason: "No reference output was provided" };
      const matches = canonicalJson(expected) === canonicalJson(output);
      return { score: matches ? 1 : 0, reason: matches ? "Output matches the reference" : "Output differs from the reference" };
    },
  };
}

export interface NumericToleranceOptions {
  absoluteTolerance?: number;
  relativeTolerance?: number;
}

function requireFiniteNumber(value: number, name: string): void {
  if (!Number.isFinite(value)) throw new TypeError(`${name} must be a finite number`);
}

export function numericTolerance<Input extends JsonValue = JsonValue, Output extends JsonValue = JsonValue>(
  options: NumericToleranceOptions = {},
): Evaluator<Input, Output> {
  const absoluteTolerance = options.absoluteTolerance === undefined ? 0 : options.absoluteTolerance;
  const relativeTolerance = options.relativeTolerance === undefined ? 0 : options.relativeTolerance;
  requireFiniteNumber(absoluteTolerance, "absoluteTolerance");
  requireFiniteNumber(relativeTolerance, "relativeTolerance");
  if (absoluteTolerance < 0 || relativeTolerance < 0) {
    throw new TypeError("Numeric tolerances must be nonnegative");
  }

  return {
    id: "numeric-tolerance",
    version: "1",
    parameters: { absoluteTolerance, relativeTolerance },
    kind: "gate",
    threshold: 1,
    evaluate({ expected, output }) {
      if (typeof expected !== "number" || !Number.isFinite(expected)) {
        return { score: null, reason: "A finite numeric reference is required" };
      }
      if (typeof output !== "number" || !Number.isFinite(output)) {
        return { score: 0, reason: "Output must be a finite number" };
      }
      const absoluteError = Math.abs(output - expected);
      // Opposite finite extremes can overflow subtraction; their ratio still
      // represents the relative error without treating Infinity <= Infinity as a pass.
      const relativeError = expected === 0
        ? (output === 0 ? 0 : Infinity)
        : (Number.isFinite(absoluteError)
            ? absoluteError / Math.abs(expected)
            : Math.abs(output / expected - 1));
      const passes = absoluteError <= absoluteTolerance || relativeError <= relativeTolerance;
      return {
        score: passes ? 1 : 0,
        reason: passes
          ? "Output is within the absolute or relative tolerance"
          : "Output exceeds both absolute and relative tolerances",
      };
    },
  };
}

export function numberRange<Input extends JsonValue = JsonValue, Output extends JsonValue = JsonValue>(
  options: { minimum: number; maximum: number },
): Evaluator<Input, Output> {
  const { minimum, maximum } = options;
  requireFiniteNumber(minimum, "minimum");
  requireFiniteNumber(maximum, "maximum");
  if (minimum > maximum) throw new TypeError("minimum cannot exceed maximum");

  return {
    id: "number-range",
    version: "1",
    parameters: { minimum, maximum },
    kind: "gate",
    threshold: 1,
    evaluate({ output }) {
      const passes = typeof output === "number" && Number.isFinite(output) && output >= minimum && output <= maximum;
      return {
        score: passes ? 1 : 0,
        reason: passes ? "Output is inside the inclusive numeric range" : "Output must be a finite number inside the inclusive numeric range",
      };
    },
  };
}
